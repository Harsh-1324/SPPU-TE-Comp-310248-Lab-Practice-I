import java.io.*;
import java.util.StringTokenizer;

public class pass11 {
    public static void main(String args[]) throws Exception {
        int loc = 0;
        int sym = 0, lit = 0, v = 0;
        String s;

        FileReader f1 = new FileReader("in.txt");
        BufferedReader b1 = new BufferedReader(f1);
        BufferedWriter b3 = new BufferedWriter(new FileWriter("symboltab.txt"));
        BufferedWriter b4 = new BufferedWriter(new FileWriter("intermediate.txt"));
        BufferedWriter b5 = new BufferedWriter(new FileWriter("literaltab.txt"));

        String s1[] = new String[5];
        String s2[] = new String[3];
        String s5[][] = new String[20][2]; // literal table

        while ((s = b1.readLine()) != null) {
            if (s.trim().isEmpty()) continue; // skip empty lines

            int m = 0;
            StringTokenizer st = new StringTokenizer(s);
            while (st.hasMoreTokens() && m < 5) {
                s1[m] = st.nextToken();
                m++;
            }

            // fill remaining nulls to avoid NPE
            for (int i = m; i < 5; i++) s1[i] = "";

            // START
            if (s1[0].equalsIgnoreCase("START")) {
                b4.write("AD 01\tC " + s1[1]);
                loc = Integer.parseInt(s1[1]);
                b4.newLine();
                continue;
            }

            // END
            else if (s1[0].equalsIgnoreCase("END")) {
                for (int i = 0; i < lit; i++) {
                    b4.write(loc + "\tAD 02\tC " + (i + 1));
                    loc++;
                    b4.newLine();
                }
                continue;
            }

            // LTORG
            else if (s1[0].equalsIgnoreCase("LTORG")) {
                for (int i = 0; i < lit; i++) {
                    b4.write(loc + "\tAD 04\t" + s5[i][1]);
                    loc++;
                    b4.newLine();
                }
                continue;
            }

            // normal line
            b4.write(loc + "\t");

            if (!s1[0].equals("-") && !s1[0].isEmpty()) {
                sym++;
                b3.write(sym + "\t" + s1[0] + "\t" + loc);
                b3.newLine();
            }

            FileReader f2 = new FileReader("op.txt");
            BufferedReader b2 = new BufferedReader(f2);
            String sl;
            while ((sl = b2.readLine()) != null) {
                StringTokenizer se = new StringTokenizer(sl);
                int j = 0;
                while (se.hasMoreTokens() && j < 3) {
                    s2[j] = se.nextToken();
                    j++;
                }
                for (int i = j; i < 3; i++) s2[i] = "";

                if (s1[1].equalsIgnoreCase(s2[0])) {
                    b4.write(s2[1] + "\t" + s2[2] + "\t");
                }
            }
            b2.close();

            // operand check
            if (s1.length > 3 && s1[3] != null && s1[3].contains("=")) {
                int flag = 0, i;
                for (i = 0; i < lit; i++) {
                    if (s5[i][1] != null && s5[i][1].equals(s1[3])) {
                        flag = 1;
                        break;
                    }
                }
                if (flag == 0) {
                    lit++;
                    s5[v][0] = Integer.toString(lit);
                    s5[v][1] = s1[3];
                    v++;
                    b5.write(lit + "\t" + s1[3]);
                    b5.newLine();
                    b4.write("L\t" + lit);
                } else {
                    b4.write("L\t" + s5[i][0]);
                }
            } else if (!s1[2].isEmpty()) {
                b4.write("S\t" + s1[2]);
            }

            loc++;
            b4.newLine();
        }

        b4.close();
        b3.close();
        b5.close();
        b1.close();

        System.out.println("Pass 1 completed successfully!");
    }
}

