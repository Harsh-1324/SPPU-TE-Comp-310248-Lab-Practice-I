import java.util.*;
import java.io.*;

class MntTuple {
    String name;
    int index;

    MntTuple(String s, int i) {
        name = s;
        index = i;
    }

    @Override
    public String toString() {
        return "[" + name + "," + index + "]";
    }
}

public class mpass11 {
    static List<MntTuple> mnt;
    static List<String> mdt;
    static int mntc;
    static int mdtc;
    static BufferedReader input;
    static List<List<String>> ala;
    static Map<String, Integer> ala_macro_binding;

    public static void main(String args[]) throws Exception {
        initializeTables();
        System.out.println("===== PASS1 =====\n");
        pass1();
    }

    static void pass1() throws Exception {
        String s;
        input = new BufferedReader(new InputStreamReader(new FileInputStream("input2.txt")));
        PrintWriter output = new PrintWriter(new FileOutputStream("output_pass1.txt"), true);

        try {
            while ((s = input.readLine()) != null) {
                s = s.trim();
                if (s.isEmpty())
                    continue;

                // If the line is the start of a macro definition
                if (s.equalsIgnoreCase("MACRO")) {
                    // process the macro header and body
                    processMacroDefinition();
                } else {
                    // normal output line (non-macro) copied to output_pass1.txt
                    output.println(s);
                }
            }
        } finally {
            // close readers/writers
            if (input != null) input.close();
            if (output != null) output.close();
        }

        System.out.println("ALA:");
        showAla(1);
        System.out.println("\nMNT:");
        showMnt();
        System.out.println("\nMDT:");
        showMdt();
    }

    // parse header line, add MNT entry, then add MDT lines (macro body)
    static void processMacroDefinition() throws Exception {
        // read macro header line (e.g. "INCR &ARG1,&ARG2=5")
        String header = input.readLine();
        if (header == null) return;
        header = header.trim();
        if (header.isEmpty()) return;

        // Add to MNT and ALA
        pass1Ala(header); // extracts formal parameters to ALA

        // get macro name (first token)
        StringTokenizer stHeader = new StringTokenizer(header, " ,", false);
        String macro_name = stHeader.nextToken();

        // Add MNT entry with current MDT index
        mnt.add(new MntTuple(macro_name, mdtc));
        mntc++;

        // Build an MDT header record for the macro (store header as one line)
        StringBuilder mdtHeader = new StringBuilder();
        mdtHeader.append(macro_name);
        while (stHeader.hasMoreTokens()) {
            mdtHeader.append(" ").append(stHeader.nextToken());
        }
        mdt.add(mdtHeader.toString());
        mdtc++;

        // now read the macro body lines and add them into MDT
        // ALA index will be last added = ala.size()-1
        addIntoMdt(ala.size() - 1);
    }

    // Extracts formal parameters from header and adds to ALA
    static void pass1Ala(String s) {
        // split on commas and/or spaces, but preserve tokens starting with '&'
        StringTokenizer st = new StringTokenizer(s, " ,", false);
        String macro_name = st.nextToken();
        List<String> paramList = new ArrayList<>();

        while (st.hasMoreTokens()) {
            String token = st.nextToken();
            // if token has default value like "&ARG=5", remove "=5"
            int eq = token.indexOf('=');
            if (eq != -1) token = token.substring(0, eq);
            // only interested in parameter tokens (typically start with &)
            if (!token.isEmpty()) paramList.add(token);
        }

        ala.add(paramList);
        // bind macro name to ALA index (use current size-1)
        ala_macro_binding.put(macro_name, ala_macro_binding.size());
    }

    // Read macro body until MEND and add lines to MDT, substituting parameters with #'s
    static void addIntoMdt(int ala_number) throws Exception {
        List<String> paramList = ala.get(ala_number);
        String s;
        while (true) {
            s = input.readLine();
            if (s == null) {
                // EOF reached unexpectedly, just break
                break;
            }
            s = s.trim();
            // if this is MEND, add a marker and stop
            if (s.equalsIgnoreCase("MEND")) {
                mdt.add("MEND");
                mdtc++;
                break;
            }
            // tokenize this body line
            StringBuilder line = new StringBuilder();
            StringTokenizer st = new StringTokenizer(s, " ,", false);

            if (!st.hasMoreTokens()) {
                // blank line inside macro body - skip
                continue;
            }

            // first token (opcode or label)
            String temp = st.nextToken();
            // pad or keep it (original code padded to 12 char; not strictly necessary)
            line.append(temp);

            boolean isFirst = true;
            while (st.hasMoreTokens()) {
                String tok = st.nextToken();
                if (tok.startsWith("&")) {
                    // parameter reference -> replace with #index
                    int idx = paramList.indexOf(tok);
                    if (idx >= 0) {
                        tok = ",#" + idx;
                    } else {
                        // if not found keep as is
                        tok = "," + tok;
                    }
                    isFirst = false;
                } else {
                    if (!isFirst) {
                        tok = "," + tok;
                    } else {
                        // first operand (no comma at front)
                        // leave as-is
                    }
                    isFirst = false;
                }
                line.append(tok);
            }

            mdt.add(line.toString());
            mdtc++;
        }
    }

    static void showAla(int pass) throws Exception {
        PrintWriter out = new PrintWriter(new FileOutputStream("out_ala_pass" + pass + ".txt"), true);
        try {
            for (List<String> l : ala) {
                System.out.println(l);
                out.println(l);
            }
        } finally {
            out.close();
        }
    }

    static void showMnt() throws Exception {
        PrintWriter out = new PrintWriter(new FileOutputStream("out_mnt.txt"), true);
        try {
            for (MntTuple t : mnt) {
                System.out.println(t);
                out.println(t);
            }
        } finally {
            out.close();
        }
    }

    static void showMdt() throws Exception {
        PrintWriter out = new PrintWriter(new FileOutputStream("out_mdt.txt"), true);
        try {
            for (String l : mdt) {
                System.out.println(l);
                out.println(l);
            }
        } finally {
            out.close();
        }
    }

    static void initializeTables() {
        mnt = new LinkedList<>();
        mdt = new ArrayList<>();
        ala = new LinkedList<>();
        mntc = 0;
        mdtc = 0;
        ala_macro_binding = new HashMap<>();
    }
}
