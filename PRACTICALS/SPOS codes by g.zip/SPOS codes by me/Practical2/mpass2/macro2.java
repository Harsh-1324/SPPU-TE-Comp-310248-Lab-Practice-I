import java.util.*;
import java.io.*;

class MntTuple {
    String name;
    int index; // index in MDT where this macro's header is stored

    MntTuple(String s, int i) {
        name = s;
        index = i;
    }

    @Override
    public String toString() {
        return "[" + name + ", " + index + "]";
    }
}

class ALAEntry {
    List<String> params;    // parameter names (without &)
    List<String> defaults;  // default values (null if none)

    ALAEntry() {
        params = new ArrayList<>();
        defaults = new ArrayList<>();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{");
        for (int i = 0; i < params.size(); i++) {
            sb.append(params.get(i));
            if (defaults.get(i) != null) sb.append("=" + defaults.get(i));
            if (i < params.size() - 1) sb.append(", ");
        }
        sb.append("}");
        return sb.toString();
    }
}

public class macro2 {
    static List<MntTuple> mnt;
    static List<String> mdt;
    static List<ALAEntry> ala;
    static Map<String, Integer> ala_macro_binding; // macroName -> ALA index

    public static void main(String args[]) throws Exception {
        initializeTables();
        System.out.println("===== PASS 1 =====\n");
        pass1();
        System.out.println("\n===== PASS 2 =====\n");
        pass2();
    }

    static void initializeTables() {
        mnt = new ArrayList<>();
        mdt = new ArrayList<>();
        ala = new ArrayList<>();
        ala_macro_binding = new HashMap<>();
    }

    // PASS 1: build MNT, MDT, ALA and write non-macro lines to output_pass1.txt
    static void pass1() throws Exception {
        BufferedReader input = new BufferedReader(new InputStreamReader(new FileInputStream("input2.txt")));
        PrintWriter output = new PrintWriter(new FileOutputStream("output_pass1.txt"), true);

        String line;
        while ((line = input.readLine()) != null) {
            line = line.trim();
            if (line.isEmpty()) continue;

            if (line.equalsIgnoreCase("MACRO")) {
                String header = input.readLine();
                if (header == null) break;
                header = header.trim();
                processMacroDefinition(header, input);
            } else {
                output.println(line);
            }
        }

        input.close();
        output.close();

        // dump tables
        System.out.println("ALA:");
        showAla(1);
        System.out.println("\nMNT:");
        showMnt();
        System.out.println("\nMDT:");
        showMdt();
    }

    // Parse macro header, add entries to MNT and ALA, add header to MDT and then body
    static void processMacroDefinition(String header, BufferedReader input) throws Exception {
        // header example: INCR &X,&Y,&REG=AREG
        String[] tokens = header.split("\\s+", 2);
        String macroName = tokens[0].trim();

        // create ALA entry and parse parameters & defaults
        ALAEntry alaEntry = new ALAEntry();

        if (tokens.length > 1) {
            String paramsPart = tokens[1].trim();
            String[] pList = paramsPart.split("\\s*,\\s*");
            for (String p : pList) {
                p = p.trim();
                if (p.startsWith("&")) p = p.substring(1);
                String paramName = p;
                String defaultVal = null;
                int eq = p.indexOf('=');
                if (eq != -1) {
                    paramName = p.substring(0, eq);
                    defaultVal = p.substring(eq + 1);
                }
                alaEntry.params.add(paramName);
                alaEntry.defaults.add(defaultVal);
            }
        }

        // add ALA and binding
        ala.add(alaEntry);
        ala_macro_binding.put(macroName, ala.size() - 1);

        // Add MNT entry pointing to current MDT index
        int mdtIndex = mdt.size();
        mnt.add(new MntTuple(macroName, mdtIndex));

        // add MDT header (store header so we can inspect defaults if needed)
        mdt.add(header);
        // add body lines until MEND
        addIntoMdt(ala.size() - 1, input);
    }

    // Reads macro body lines and adds them to MDT; replaces parameter occurrences with #index placeholders
    static void addIntoMdt(int ala_number, BufferedReader input) throws Exception {
        ALAEntry entry = ala.get(ala_number);
        String s;
        while ((s = input.readLine()) != null) {
            s = s.trim();
            if (s.isEmpty()) continue;
            if (s.equalsIgnoreCase("MEND")) {
                mdt.add("MEND");
                break;
            }
            StringTokenizer st = new StringTokenizer(s, " ,", false);
            StringBuilder outLine = new StringBuilder();
            boolean firstToken = true;
            while (st.hasMoreTokens()) {
                String tok = st.nextToken();
                String replaced = tok;
                if (tok.startsWith("&")) {
                    String name = tok.substring(1);
                    int idx = entry.params.indexOf(name);
                    if (idx >= 0) replaced = "#" + idx;
                }
                if (firstToken) {
                    outLine.append(replaced);
                    firstToken = false;
                } else {
                    outLine.append("," + replaced);
                }
            }
            mdt.add(outLine.toString());
        }
    }

    static void showAla(int pass) throws Exception {
        PrintWriter out = new PrintWriter(new FileOutputStream("out_ala_pass" + pass + ".txt"), true);
        int i = 0;
        for (ALAEntry e : ala) {
            System.out.println("ALA[" + i + "] " + e.toString());
            out.println("ALA[" + i + "] " + e.toString());
            i++;
        }
        out.close();
    }

    static void showMnt() throws Exception {
        PrintWriter out = new PrintWriter(new FileOutputStream("out_mnt.txt"), true);
        for (MntTuple t : mnt) {
            System.out.println(t.toString());
            out.println(t.toString());
        }
        out.close();
    }

    static void showMdt() throws Exception {
        PrintWriter out = new PrintWriter(new FileOutputStream("out_mdt.txt"), true);
        int i = 0;
        for (String s : mdt) {
            System.out.println(i + ": " + s);
            out.println(i + ": " + s);
            i++;
        }
        out.close();
    }

    // PASS 2: read output_pass1.txt and expand macro invocations using MNT/MDT/ALA
    static void pass2() throws Exception {
        BufferedReader in = new BufferedReader(new FileReader("output_pass1.txt"));
        PrintWriter out = new PrintWriter(new FileOutputStream("output_pass2.txt"), true);
        String s;
        while ((s = in.readLine()) != null) {
            s = s.trim();
            if (s.isEmpty()) continue;

            String[] parts = s.split("\\s+", 2);
            String first = parts[0];

            MntTuple invoked = null;
            for (MntTuple t : mnt) {
                if (t.name.equalsIgnoreCase(first)) {
                    invoked = t;
                    break;
                }
            }

            if (invoked == null) {
                out.println(s);
                System.out.println(s);
            } else {
                int mdtIndex = invoked.index;
                int alaIndex = ala_macro_binding.get(invoked.name);
                ALAEntry template = ala.get(alaIndex);

                // prepare instance args starting from defaults
                List<String> instanceArgs = new ArrayList<>();
                for (String d : template.defaults) instanceArgs.add(d);

                // parse actual args into positional and named
                List<String> positional = new ArrayList<>();
                Map<Integer, String> namedAssignments = new HashMap<>();
                if (parts.length > 1) {
                    String actuals = parts[1].trim();
                    String[] actList = actuals.split("\\s*,\\s*");
                    for (String a : actList) {
                        a = a.trim();
                        if (a.isEmpty()) continue;
                        if (a.contains("=")) {
                            String[] nv = a.split("=", 2);
                            String name = nv[0].trim();
                            String value = nv[1].trim();
                            String cleanName = name.startsWith("&") ? name.substring(1) : name;
                            int idx = template.params.indexOf(cleanName);
                            if (idx >= 0) namedAssignments.put(idx, value);
                        } else {
                            positional.add(a);
                        }
                    }
                }

                // apply named assignments
                for (Map.Entry<Integer, String> e : namedAssignments.entrySet()) {
                    instanceArgs.set(e.getKey(), e.getValue());
                }
                // fill positional into first non-named slots
                int posIndex = 0;
                for (int i = 0; i < instanceArgs.size() && posIndex < positional.size(); i++) {
                    if (!namedAssignments.containsKey(i)) {
                        instanceArgs.set(i, positional.get(posIndex++));
                    }
                }
                // ensure no nulls
                for (int i = 0; i < instanceArgs.size(); i++) {
                    if (instanceArgs.get(i) == null) instanceArgs.set(i, "");
                }

                // Expand MDT: header stored at invoked.index, body at invoked.index+1 ...
                int p = invoked.index + 1;
                while (p < mdt.size()) {
                    String mline = mdt.get(p).trim();
                    if (mline.equalsIgnoreCase("MEND")) break;

                    String expanded = mline;
                    for (int i = 0; i < instanceArgs.size(); i++) {
                        expanded = expanded.replace("#" + i, instanceArgs.get(i));
                    }
                    out.println(expanded.replaceAll(",+", ","));
                    System.out.println(expanded.replaceAll(",+", ","));
                    p++;
                }
            }
        }

        in.close();
        out.close();

        System.out.println("\nALA (after pass2):");
        showAla(2);
    }
}
